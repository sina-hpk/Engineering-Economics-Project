
from flask import Flask, render_template, request, jsonify
import math

app = Flask(__name__)

def calculate_npv(rate, cash_flows):
    npv = sum(cf / ((1 + rate) ** t) for t, cf in enumerate(cash_flows, start=1))
    return npv

def calculate_roi(initial_cost, total_income):
    return (total_income - initial_cost) / initial_cost * 100

def calculate_payback(initial_cost, net_annual):
    if net_annual <= 0:
        return float('inf')
    return initial_cost / net_annual

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    try:
        data = request.get_json()
        rate = float(data['interest_rate']) / 100
        tax_enabled = data['tax_enabled']
        tax_rate = float(data['tax_rate']) / 100 if tax_enabled else 0
        method = data['method']
        projects = data['projects']

        results = []

        for p in projects:
            name = p['name']
            initial_cost = float(p['initial_cost'])
            annual_income = float(p['annual_income'])
            annual_expense = float(p['annual_expense'])
            years = int(p['years'])
            salvage_enabled = p['salvage_enabled']
            salvage_value = float(p['salvage_value']) if salvage_enabled else 0

            taxable_income = annual_income - annual_expense
            net_income = taxable_income * (1 - tax_rate)
            net_cash_flow = net_income

            cash_flows = [net_cash_flow] * years
            if salvage_enabled:
                cash_flows[-1] += salvage_value

            npv = calculate_npv(rate, cash_flows) - initial_cost
            roi = calculate_roi(initial_cost, sum(cash_flows))
            payback = calculate_payback(initial_cost, net_cash_flow)

            results.append({
                'name': name,
                'initial_cost': initial_cost,
                'annual_income': annual_income,
                'annual_expense': annual_expense,
                'years': years,
                'salvage_value': salvage_value if salvage_enabled else '-',
                'npv': round(npv, 2),
                'roi': round(roi, 2),
                'payback': round(payback, 2) if payback != float('inf') else 'نامشخص'
            })

        if method == 'npv':
            best = max(results, key=lambda x: x['npv'])
        elif method == 'roi':
            best = max(results, key=lambda x: x['roi'])
        else:
            best = min(results, key=lambda x: float('inf') if x['payback'] == 'نامشخص' else x['payback'])

        return jsonify({'results': results, 'best': best['name']})

    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True)
